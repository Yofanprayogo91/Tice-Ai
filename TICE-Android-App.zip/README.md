# TICE AI — Asisten Virtual Pria 3D (Android APK)

Proyek Android siap-build untuk **TICE AI** lengkap dengan:
- **Native Android SpeechRecognizer Bridge** (Mikrofon Bahasa Indonesia berjalan langsung di dalam APK).
- **Native Android TextToSpeech Fallback** (Suara tetap keluar di HP Android meski tanpa API Key).
- **Dukungan Upload File** (Unggah foto wajah asli & file model 3D `.GLB` lokal).
- **Ready Player Me `.GLB` + Lip-Sync MorphTargets** dengan fallback otomatis ke Avatar 3D bawaan.
- **GitHub Actions Workflow** (`.github/workflows/build-apk.yml`) untuk mem-build file `.APK` otomatis tanpa perlu PC/Android Studio.

## Cara Build APK Otomatis di GitHub
1. Buat repository baru di GitHub.
2. Upload semua isi proyek ini ke repository tersebut (pastikan folder `.github` dan `app` berada di root repository).
3. Buka tab **Actions** di GitHub, pilih **Build TICE Android APK**, lalu tunggu hingga status centang hijau.
4. Klik run yang selesai, scroll ke bagian **Artifacts**, lalu unduh **TICE-AI-Android-APK** dan install file `TICE-AI-v1.0.apk` di HP Android Anda.
