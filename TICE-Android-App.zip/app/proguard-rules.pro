# Keep JavaScript Bridge methods
-keepclassmembers class com.tice.assistant.MainActivity$AndroidBridge {
   public *;
}
