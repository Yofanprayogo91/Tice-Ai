package com.tice.assistant;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_RECORD_AUDIO = 1001;

    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private boolean pendingStartListening = false;

    private ValueCallback<Uri[]> fileUploadCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;
    private long lastBackPressedTime = 0L;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full dark WebView container
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF060B16);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);

        // Register modern ActivityResultLauncher for Photo & .GLB file uploads
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (fileUploadCallback == null) return;
                    Uri[] uris = null;
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        if (data.getData() != null) {
                            uris = new Uri[]{ data.getData() };
                        } else if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                            int count = data.getClipData().getItemCount();
                            uris = new Uri[count];
                            for (int i = 0; i < count; i++) {
                                uris[i] = data.getClipData().getItemAt(i).getUri();
                            }
                        }
                    }
                    fileUploadCallback.onReceiveValue(uris);
                    fileUploadCallback = null;
                }
        );

        initWebView();
        initNativeTTS();
        requestAudioPermissionIfNeeded();

        webView.loadUrl("file:///android_asset/index.html");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initWebView() {
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                }
                fileUploadCallback = filePathCallback;
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] types = fileChooserParams.getAcceptTypes();
                    if (types != null && types.length > 0 && types[0] != null && types[0].startsWith("image/")) {
                        intent.setType("image/*");
                    } else {
                        intent.setType("*/*");
                    }
                    fileChooserLauncher.launch(Intent.createChooser(intent, "Pilih File untuk TICE"));
                    return true;
                } catch (Exception e) {
                    fileUploadCallback = null;
                    Toast.makeText(MainActivity.this, "Gagal membuka pemilih file.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
    }

    private void initNativeTTS() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = textToSpeech.setLanguage(new Locale("id", "ID"));
                ttsReady = (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED);
                if (!ttsReady) {
                    textToSpeech.setLanguage(Locale.getDefault());
                    ttsReady = true;
                }
                textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        evalJs("window.onNativeTTSStart && window.onNativeTTSStart();");
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        evalJs("window.onNativeTTSEnd && window.onNativeTTSEnd();");
                    }

                    @Override
                    public void onError(String utteranceId) {
                        evalJs("window.onNativeTTSEnd && window.onNativeTTSEnd();");
                    }
                });
            }
        });
    }

    private void requestAudioPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingStartListening) {
                    pendingStartListening = false;
                    startNativeSpeech();
                }
            } else {
                pendingStartListening = false;
                evalJs("window.onNativeSTTError && window.onNativeSTTError('Izin mikrofon ditolak.');");
            }
        }
    }

    private void startNativeSpeech() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStartListening = true;
            requestAudioPermissionIfNeeded();
            return;
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            evalJs("window.onNativeSTTError && window.onNativeSTTError('Layanan Google Speech tidak tersedia di perangkat.');");
            return;
        }

        stopNativeSpeech();

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                evalJs("window.onNativeSTTStart && window.onNativeSTTStart();");
            }

            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {
                evalJs("window.onNativeSTTEnd && window.onNativeSTTEnd();");
            }

            @Override
            public void onError(int error) {
                String msg;
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    msg = "Suara tidak terdengar. Coba bicara lebih dekat.";
                } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    msg = "Izin mikrofon diperlukan.";
                } else {
                    msg = "Gagal mengenali suara (kode " + error + ").";
                }
                evalJs("window.onNativeSTTError && window.onNativeSTTError(" + JSONObject.quote(msg) + ");");
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    evalJs("window.onNativeSTTResult && window.onNativeSTTResult(" + JSONObject.quote(matches.get(0)) + ");");
                } else {
                    evalJs("window.onNativeSTTEnd && window.onNativeSTTEnd();");
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                ArrayList<String> partial = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (partial != null && !partial.isEmpty()) {
                    evalJs("window.onNativeSTTPartial && window.onNativeSTTPartial(" + JSONObject.quote(partial.get(0)) + ");");
                }
            }

            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);

        speechRecognizer.startListening(intent);
    }

    private void stopNativeSpeech() {
        if (speechRecognizer != null) {
            try {
                speechRecognizer.stopListening();
                speechRecognizer.cancel();
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
            speechRecognizer = null;
        }
    }

    private void evalJs(final String script) {
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript(script, null);
            }
        });
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void startSpeechRecognition() {
            runOnUiThread(() -> startNativeSpeech());
        }

        @JavascriptInterface
        public void stopSpeechRecognition() {
            runOnUiThread(() -> stopNativeSpeech());
        }

        @JavascriptInterface
        public void speakNative(final String text, final float rate, final float pitch) {
            runOnUiThread(() -> {
                if (textToSpeech != null && ttsReady) {
                    textToSpeech.setSpeechRate(Math.max(0.5f, Math.min(2.0f, rate)));
                    textToSpeech.setPitch(Math.max(0.5f, Math.min(1.5f, pitch)));
                    Bundle params = new Bundle();
                    params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "TICE_UTTERANCE");
                    textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, params, "TICE_UTTERANCE");
                } else {
                    evalJs("window.onNativeTTSEnd && window.onNativeTTSEnd();");
                }
            });
        }

        @JavascriptInterface
        public void stopNativeTTS() {
            runOnUiThread(() -> {
                if (textToSpeech != null) {
                    textToSpeech.stop();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBackPressedTime < 2000) {
            super.onBackPressed();
        } else {
            lastBackPressedTime = now;
            Toast.makeText(this, "Tekan kembali sekali lagi untuk keluar dari TICE", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        stopNativeSpeech();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
